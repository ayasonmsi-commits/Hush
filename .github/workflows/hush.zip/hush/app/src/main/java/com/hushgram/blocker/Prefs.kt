package com.hushgram.blocker

object Prefs {
    const val NAME = "hushgram"
    const val REELS = "block_reels"            // Reels tab + reels opened from feed/profiles
    const val DM_REELS = "block_dm_reels"      // reels friends send you in DMs
    const val FEED_REELS = "block_feed_reels"  // auto-skip reels inside the home feed
    const val EXPLORE = "block_explore"
    const val STORIES = "block_stories"
    const val ADS = "block_ads"
    const val DEBUG = "record_ids"
    const val LAST_IDS = "last_ids"
    const val EVENTS = "events_seen"
    const val CONNECTED_AT = "connected_at"

    val toggles = listOf(
        REELS to "Block Reels (tab + opened reels)",
        DM_REELS to "Block reels friends send in DMs",
        FEED_REELS to "Skip reels in the home feed",
        EXPLORE to "Block Explore (search for people still works)",
        STORIES to "Block Stories",
        ADS to "Skip ads / sponsored posts",
    )
}

/**
 * Instagram view-ID fragments. Instagram renames these sometimes —
 * if something stops being blocked, turn on "Record screen IDs",
 * open that screen, copy the IDs from the app and update these lists.
 */
object Ids {
    const val PKG = "com.instagram.android"
    val REELS_VIEWER = listOf("clips_viewer", "clips_video_container", "clips_ufi", "clips_tab_container")
    val FEED_REEL = listOf("clips_media_view", "feed_clips", "clips_preview")
    val DM_THREAD = listOf("direct_thread", "row_thread_composer", "thread_composer", "direct_text_message")
    val EXPLORE = listOf("explore_", "explore_grid", "explore_topical")
    val SEARCH_RESULTS = listOf("row_search", "search_results", "action_bar_search_edit_text_focused")
    val STORY_VIEWER = listOf("reel_viewer_root", "reel_viewer_media_container", "reel_viewer_texture_view")
    val HOME_TAB = listOf("feed_tab")
    val SPONSORED = setOf("sponsored", "ممول", "مُموَّل", "إعلان ممول")
}
