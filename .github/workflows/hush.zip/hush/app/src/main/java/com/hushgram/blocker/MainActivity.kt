package com.hushgram.blocker

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        col.addView(TextView(this).apply {
            text = "Hush"; textSize = 28f; setTypeface(typeface, Typeface.BOLD)
        })
        col.addView(TextView(this).apply {
            text = "Instagram without the distractions. DMs are never blocked."
            setPadding(0, 0, 0, pad)
        })
        status = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, pad / 2) }
        col.addView(status)
        col.addView(Button(this).apply {
            text = "Open Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        col.addView(space(pad))

        for ((key, label) in Prefs.toggles) {
            col.addView(Switch(this).apply {
                text = label; textSize = 16f
                isChecked = prefs.getBoolean(key, true)
                setPadding(0, pad / 2, 0, pad / 2)
                setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(key, v).apply() }
            })
        }

        col.addView(space(pad * 2))
        col.addView(TextView(this).apply { text = "Fix detection (if Instagram updates)"; setTypeface(typeface, Typeface.BOLD) })
        col.addView(Switch(this).apply {
            text = "Record screen IDs"
            isChecked = prefs.getBoolean(Prefs.DEBUG, false)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(Prefs.DEBUG, v).apply() }
        })
        col.addView(Button(this).apply {
            text = "Copy last Instagram screen IDs"
            setOnClickListener {
                val ids = prefs.getString(Prefs.LAST_IDS, "") ?: ""
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("ids", ids))
                Toast.makeText(this@MainActivity,
                    if (ids.isEmpty()) "Nothing recorded yet" else "Copied", Toast.LENGTH_SHORT).show()
            }
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun space(h: Int) = View(this).apply { minimumHeight = h }

    override fun onResume() {
        super.onResume()
        val enabled = (Settings.Secure.getString(contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)
        val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        val connected = prefs.getLong(Prefs.CONNECTED_AT, 0L) > 0
        val events = prefs.getLong(Prefs.EVENTS, 0L)
        val diag = "\nService started: " + (if (connected) "yes" else "NO") + "  •  Instagram events seen: " + events
        status.text = (if (enabled) "✅ Blocker is ON" else "⚠️ Blocker is OFF. Enable Hush in Accessibility settings") + diag
    }
}
