package com.hushgram.blocker

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class BlockerService : AccessibilityService() {

    private lateinit var prefs: SharedPreferences
    private var lastScan = 0L
    private var lastAction = 0L
    private var cameFromDm = false
    private var seen = 0L

    /** Find Instagram's window even in split-screen / tablet / dual-app setups. */
    private fun igRoot(e: AccessibilityEvent): AccessibilityNodeInfo? {
        rootInActiveWindow?.let { if (it.packageName?.toString() == Ids.PKG) return it }
        try {
            for (w in windows) {
                val r = w.root ?: continue
                if (r.packageName?.toString() == Ids.PKG) return r
            }
        } catch (_: Exception) {}
        var n = e.source ?: return null
        while (true) { n = n.parent ?: return n }
    }

    override fun onServiceConnected() {
        prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        prefs.edit().putLong(Prefs.CONNECTED_AT, System.currentTimeMillis()).apply()
    }

    override fun onInterrupt() {}

    private fun on(key: String) = prefs.getBoolean(key, true)

    private class Scan {
        val ids = HashSet<String>()
        val nodesById = HashMap<String, AccessibilityNodeInfo>()
        var sponsored = false
        val scrollables = ArrayList<AccessibilityNodeInfo>()
        var count = 0
    }

    private fun walk(n: AccessibilityNodeInfo?, s: Scan, depth: Int) {
        if (n == null || depth > 70 || s.count > 4000) return
        s.count++
        n.viewIdResourceName?.substringAfter(":id/")?.let { id ->
            s.ids.add(id)
            s.nodesById.putIfAbsent(id, n)
        }
        if (!s.sponsored && n.isVisibleToUser) {
            val t = n.text?.toString()?.trim()?.lowercase()
            val d = n.contentDescription?.toString()?.trim()?.lowercase()
            if ((t != null && t in Ids.SPONSORED) || (d != null && d in Ids.SPONSORED)) s.sponsored = true
        }
        if (n.isScrollable) s.scrollables.add(n)
        for (i in 0 until n.childCount) walk(n.getChild(i), s, depth + 1)
    }

    private fun Scan.has(frags: List<String>) = ids.any { id -> frags.any { id.contains(it) } }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || !::prefs.isInitialized) return
        if (e.packageName?.toString() != Ids.PKG) return
        seen++
        if (seen % 10 == 1L) prefs.edit().putLong(Prefs.EVENTS, seen).apply()
        val now = SystemClock.uptimeMillis()
        if (now - lastScan < 200 || now - lastAction < 800) return
        lastScan = now
        val root = igRoot(e) ?: run {
            prefs.edit().putString(Prefs.LAST_IDS, "(event seen, but no Instagram window found)").apply()
            return
        }

        val s = Scan()
        walk(root, s, 0)
        if (prefs.getBoolean(Prefs.DEBUG, false)) {
            prefs.edit().putString(Prefs.LAST_IDS, s.ids.sorted().joinToString("\n")).apply()
        }

        val inDm = s.has(Ids.DM_THREAD)
        val reelViewer = s.has(Ids.REELS_VIEWER)
        val storyViewer = s.has(Ids.STORY_VIEWER)

        when {
            // Full-screen reels: decide if it came from a DM chat or elsewhere
            reelViewer && !inDm -> {
                if (cameFromDm) {
                    if (on(Prefs.DM_REELS)) block("Reel from DM blocked", goHome = false)
                } else if (on(Prefs.REELS)) block("Reels blocked", goHome = true)
            }
            storyViewer && on(Prefs.STORIES) -> block("Stories blocked", goHome = false)
            storyViewer && s.sponsored && on(Prefs.ADS) -> block("Story ad skipped", goHome = false)
            s.has(Ids.EXPLORE) && !s.has(Ids.SEARCH_RESULTS) && on(Prefs.EXPLORE) ->
                block("Explore blocked", goHome = true)
            !storyViewer && s.sponsored && on(Prefs.ADS) -> skipPast(s, "Ad skipped")
            !reelViewer && s.has(Ids.FEED_REEL) && on(Prefs.FEED_REELS) -> skipPast(s, "Reel skipped")
        }

        // remember whether the user is in a DM chat, keep it while a reel opened from there is showing
        cameFromDm = inDm || (cameFromDm && reelViewer)
    }

    private fun block(msg: String, goHome: Boolean) {
        lastAction = SystemClock.uptimeMillis()
        val root = rootInActiveWindow?.takeIf { it.packageName?.toString() == Ids.PKG }
            ?: try { windows.firstNotNullOfOrNull { w -> w.root?.takeIf { it.packageName?.toString() == Ids.PKG } } } catch (_: Exception) { null }
        var done = false
        if (goHome && root != null) {
            val s = Scan(); walk(root, s, 0)
            val home = Ids.HOME_TAB.firstNotNullOfOrNull { s.nodesById[it] }
            if (home != null) done = clickUp(home)
        }
        if (!done) performGlobalAction(GLOBAL_ACTION_BACK)
        toast(msg)
    }

    private fun clickUp(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        while (cur != null) {
            if (cur.isClickable) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur.parent
        }
        return false
    }

    private fun skipPast(s: Scan, msg: String) {
        lastAction = SystemClock.uptimeMillis()
        // biggest scrollable list on screen = the feed
        val feed = s.scrollables.maxByOrNull { n ->
            val r = android.graphics.Rect(); n.getBoundsInScreen(r); r.width() * r.height()
        } ?: return
        feed.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
        toast(msg)
    }

    private fun toast(msg: String) =
        Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
}
