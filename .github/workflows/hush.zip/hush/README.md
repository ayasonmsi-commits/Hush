# Hush

Blocks Reels, Explore, Stories, ads and feed reels inside the **official Instagram app**, each one optional. DMs are never touched.

## Get the APK (no Android Studio needed)
1. Create a new GitHub repo and upload this folder (keep the `.github` folder).
2. Open the **Actions** tab. The "Build APK" job runs automatically (about 3–5 min).
3. Open the finished run, download **Hush-apk**, unzip it, and install `app-debug.apk` on your phone.

## Setup on the phone
1. Open Hush, then tap **Open Accessibility settings**, then Hush, then turn it on.
   - Android 13+: if it's greyed out, go to App info → ⋮ → **Allow restricted settings** first.
2. Pick what to block with the switches.

## If something stops getting blocked
Instagram renames its screens sometimes. Turn on **Record screen IDs**, open the screen in Instagram, come back, tap **Copy**, then update the lists in `Prefs.kt` (`Ids` object).
